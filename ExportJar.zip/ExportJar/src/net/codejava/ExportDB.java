package net.codejava;
 
import java.io.*;
import java.sql.*;
 

public class ExportDB {
 
    public static void main(String[] args) {
        String jdbcURL = "jdbc:mysql://localhost:3306/jasper";
        String username = "root";
        String password1 = "root";
        String csvFilePath = "Reviews-export.csv";
        try (Connection connection = DriverManager.getConnection(jdbcURL, username, password1)) {
            String sql = "SELECT * FROM student";
             
            Statement statement = connection.createStatement();
             
            ResultSet result = statement.executeQuery(sql);
             
            BufferedWriter fileWriter = new BufferedWriter(new FileWriter(csvFilePath));
                  
            fileWriter.write("name, address, password, roll");
             
            while (result.next()) {
                String name = result.getString("name");
                String address = result.getString("address");
                String password = result.getString("password");
                String roll = result.getString("roll");
                
                 
                if (roll == null) {
                    roll = "";   
                } else {
                    roll = "\"" + roll + "\""; 
                }
                 
                String line = String.format("\"%s\",%s,%s,%s",name, address, password, roll);
                 
                fileWriter.newLine();
                fileWriter.write(line);       
                System.out.println("export"+line);
            }
             
            statement.close();
            fileWriter.close();
             
        } catch (SQLException e) {
            System.out.println("Datababse error:");
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("File IO error:");
            e.printStackTrace();
        }
         
    }
 
}