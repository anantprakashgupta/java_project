package dto;

import java.io.Serializable;

public class BltTrxBeen {
	private int id;
	private String File_Name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFile_Name() {
		return File_Name;
	}
	public void setFile_Name(String file_Name) {
		
		File_Name = file_Name;
	}
	public BltTrxBeen(int id, String file_Name) {
		super();
		this.id = id;
		File_Name = file_Name;
	}
	public BltTrxBeen(String file_Name) {
		super();
		File_Name = file_Name;
	}
	public BltTrxBeen() {
		// TODO Auto-generated constructor stub
	}

}

