package com.path.dao;
import java.io.File;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.path.Connection.DBConnection;
import dto.BltTrxBeen;


public class BltTrxDao {
		public  boolean insertFileName(String fn) {
			Connection con=null;
			
			boolean status =false;
			try {
				
				con=DBConnection.getConnection();	
				String sql="insert into BltTrx (File_Name) value(?)";
				PreparedStatement ps=con.prepareStatement(sql);
				ps.setString(1, fn);
			   
				int x=ps.executeUpdate();
				if(x!=0) {
					status =true;
				}
			
			}catch(Exception e) {
				e.printStackTrace();
			}
			
			return false;
				
		}

		public static  ArrayList<String> getFileName() {
			ArrayList<String> all=new ArrayList();
			boolean status =false;
			Connection con=null;
			String File_Name=null;
		    long fromFile;
		    ArrayList<String> arr=new ArrayList<String>();
			
			try {
				con=DbConnection.getConnection();	
				String sql="select File_Name from jasper.BltTrx order by id desc limit 1;";
			    File f=new File("//home//prakash//BltTrx");
				PreparedStatement ps=con.prepareStatement(sql);
				ResultSet rs=(ResultSet) ps.executeQuery();
				while(rs.next()){
				//int id=rs.getInt(1);
				File_Name=rs.getString(1);
				System.out.println("lastFile=" +File_Name);
				}
				File myobj=new File("//home//prakash//BltTrx" +File_Name);
				fromFile=myobj.lastModified();
				System.out.println("file name:"+ myobj.getName()+" lastmodified: "+fromFile);
				File[] listobj=f.listFiles();
				for (File f2 : listobj) {
					System.out.println(f2.getName()+"::"+f2.lastModified());
					if (f2.lastModified()> fromFile) {
						arr.add(f2.getName());
						
					}
				}
				System.out.println("arry list= "+arr);
				
				for(String a:arr) {
					System.out.println("a"+a);
					String sql2="insert into BltTrx (File_Name) value(?)";
					//System.out.println("sql2" +sql2);
					ps=con.prepareStatement(sql2);
					ps.setString(1, a);
					System.out.println(ps.executeUpdate());
				}
				
				
				con.close();
				
			}catch(Exception e) {
				e.printStackTrace();
			}
			return all;
		
		}
		public static void main(String[] args) {
			getFileName();
		}

	}


