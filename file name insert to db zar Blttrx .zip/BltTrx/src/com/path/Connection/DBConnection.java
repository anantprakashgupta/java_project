package com.path.Connection;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.properties.EncryptableProperties;


public class DBConnection {

	public static java.util.Date today;

	public static PreparedStatement st = null;
	public static CallableStatement cs = null;
	public static ResultSet rs = null;

//	  public static Connection getLaneConnection() {
//		    Connection conn = null;
//		    FileInputStream inputStream = null;
//		    FileInputStream inputStream1 = null;
//		    try {
//		      Properties properties1 = new Properties();
//		      inputStream = new FileInputStream("/usr/Toll_Soft/DataConn.properties");
//		      properties1.load(inputStream);
//		      StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
//		      encryptor.setPassword(properties1.getProperty("key"));
//		      Properties props = new EncryptableProperties(encryptor);
//		      inputStream1 = new FileInputStream("/usr/Toll_Soft/DataConn.properties");
//		      props.load(inputStream1);
//		      String driver = props.getProperty("driverClassName");
//		      Class.forName(driver);
//		      String dbURL = props.getProperty("url");
//		      String localurl = props.getProperty("localurl");
//		      String dbUsername = props.getProperty("tdwu");
//		      String dbPassword = props.getProperty("tdwup");
//		      Properties connProperties = new Properties();
////		      System.out.println("dbURL : "+dbURL);
////		      System.out.println("localurl : "+localurl);
////		      System.out.println("dbUsername : "+dbUsername);
////		      System.out.println("dbPassword : "+dbPassword);
//
//		      connProperties.put("user", dbUsername);
//		      connProperties.put("password", dbPassword);
//		      connProperties.put("autoReconnect", "true");
//		      connProperties.put("maxReconnects", "4");
//		      conn = DriverManager.getConnection(localurl, connProperties);
//		    } catch (Exception ex) {
//		      ex.printStackTrace();
//		    } finally {
//		      try {
//		        if (inputStream != null)
//		          inputStream.close(); 
//		        if (inputStream1 != null)
//		          inputStream1.close(); 
//		      } catch (Exception ex) {
//		        ex.printStackTrace();
//		      } 
//		    } 
//		    return conn;
//		  }


	  public static Connection getServerConnection() {
		    Connection conn = null;
		    FileInputStream inputStream = null;
		    FileInputStream inputStream1 = null;
		    try {
		      Properties properties1 = new Properties();
		      inputStream = new FileInputStream("/usr/Path_Toll_Software/DataConn.properties");
		      properties1.load(inputStream);
		      StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		      encryptor.setPassword(properties1.getProperty("key"));
		      Properties props = new EncryptableProperties(encryptor);
		      inputStream1 = new FileInputStream("/usr/Path_Toll_Software/DataConn.properties");
		      props.load(inputStream1);
		      String driver = props.getProperty("driverClassName");
		      Class.forName(driver);
		      String dbURL = props.getProperty("url");
		      String localurl = props.getProperty("localurl");
		      String dbUsername = props.getProperty("pdwu");
		      String dbPassword = props.getProperty("pdwup");
		      Properties connProperties = new Properties();
//		      System.out.println("dbURL : "+dbURL);
//		      System.out.println("localurl : "+localurl);
//		      System.out.println("dbUsername : "+dbUsername);
//		      System.out.println("dbPassword : "+dbPassword);

		      connProperties.put("user", dbUsername);
		      connProperties.put("password", dbPassword);
		      connProperties.put("autoReconnect", "true");
		      connProperties.put("maxReconnects", "4");
		      conn = DriverManager.getConnection(dbURL, connProperties);
		    } catch (Exception ex) {
		      ex.printStackTrace();
		    } finally {
		      try {
		        if (inputStream != null)
		          inputStream.close(); 
		        if (inputStream1 != null)
		          inputStream1.close(); 
		      } catch (Exception ex) {
		        ex.printStackTrace();
		      } 
		    } 
		    return conn;
		  }
	
	  public static void main(String[] args) { 
		  Connection conn = null; 
		  Connection conn1 = null;
		  try {
			 // conn =getLaneConnection(); 
			  conn1 = getServerConnection();
			  System.out.println("conn=" + conn + " c_conn = "+conn1);
			  } catch (Exception e) 
		  {
	 e.printStackTrace(); System.exit(1); 
	 } }

	

}