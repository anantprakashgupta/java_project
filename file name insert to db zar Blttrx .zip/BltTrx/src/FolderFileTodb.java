
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;

import com.path.Connection.DBConnection;

public class FolderFileTodb {
	public static String filereturn() throws SQLException {
		Connection conn =null;
		conn=DBConnection.getServerConnection();
		PreparedStatement ps =null;
		String lastfile=null;
		long fromfile;
		ArrayList<String> alist = new ArrayList<String>();
		
		    LocalDateTime local=LocalDateTime.now();
		    DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy-MM-dd HH-mm-ss");
		    String formatted=local.format(dtf);
		    Date date=new Date();
		    String Filepath="/home/prakash/BltTrx "+ formatted;
		    System.out.println("date= " +Filepath);

		try {
			String sql ="select * from black_list_name_2 order by srno desc limit 1";
			File myobj1 = new File("/home/prakash/BltTrx");
			ps = conn.prepareStatement(sql);
			ResultSet rs =ps.executeQuery();
			while(rs.next()) {
				lastfile=rs.getString(2);
				System.out.println("lastfile : "+lastfile);
				
			}
			File myobj = new File("/home/prakash/BltTrx"+lastfile);
			fromfile=myobj.lastModified();
			System.out.println("filename : "+myobj.getName()+" lastmodified : "+fromfile);
			File[] listobj = myobj1.listFiles();
			for(File f:listobj) {
				System.out.println(f.getName() +" :: "+f.lastModified());
				if(f.lastModified() > fromfile) {
					alist.add(f.getName());
				}
			}
			System.out.println("alist : : "+alist);	
			for(String a:alist) {
				System.out.println("file :: "+a);
				String sql1 ="insert into black_list_name_2 (filename, date_downlaod, status, path, file_id) values(?,?,?,?,?)";
				System.out.println(sql1);
				ps = conn.prepareStatement(sql1);
				ps.setString(1, a);
				ps.setString(2, formatted);
				ps.setString(3, "download");
				ps.setString(4, "1");
				ps.setString(5, "5");
				System.out.println(ps.executeUpdate());	
			}
		}catch(Exception e) {
			
			
		}
		
		return null;
	}
	
	public static void main(String[] args) throws SQLException {
		FolderFileTodb.filereturn();
	}
	
}