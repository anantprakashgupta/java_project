package controller;
import java.io.File;
import com.path.dao.BltTrxDao;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.ListIterator;

import dto.BltTrxBeen;

import com.path.dao.BltTrxDao;
public class BltTrxController {
	static ArrayList<String> arr=null;
	static String s=null;
	public static void insertFile() {
		
	    File File_Name = new File("//home//prakash//BltTrx");
        arr = new ArrayList<String>();
        for(File file : File_Name.listFiles())
        {
           arr.add(file.getName());
        }
        for (int i = 1; i < arr.size(); i++)
        {
        	s=arr.get(i);	
        	BltTrxDao dao=new BltTrxDao();
        	  dao.insertFileName(s);
        	  System.out.println(s);
		} 
      
	}
	
	public static void main(String[] args) {
		insertFile();
		
  }
	
}
