package controller;

public @interface Autowired {

}
