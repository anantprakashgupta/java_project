package controller;
import com.path.dao.BltTrxDao;
public class Show_data_BltTrx {
	
	public static void main(String[] args) {
		BltTrxDao show=new BltTrxDao();
		show.getFileName();
		
	}

}
