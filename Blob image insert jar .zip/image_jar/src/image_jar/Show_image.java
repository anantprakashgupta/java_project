package image_jar;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Show_image {

    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/jasper";
        String user = "root";
        String password = "root";

        String query = "SELECT Data FROM image LIMIT 1";

        try (Connection con = DriverManager.getConnection(url, user, password); PreparedStatement pst = con.prepareStatement(query); ResultSet result = pst.executeQuery()) {

            if (result.next()) {

                String fileName = "pk.png";

                try (FileOutputStream fos = new FileOutputStream(fileName)) {

                    Blob blob = result.getBlob("Data");
                    int len = (int) blob.length();

                    byte[] buf = blob.getBytes(1, len);

                    fos.write(buf, 0, len);
                    System.out.println(len);

                } catch (IOException ex) {

                    Logger lgr = Logger.getLogger(Show_image.class.getName());
                    lgr.log(Level.SEVERE, ex.getMessage(), ex);
                }
            }
        } catch (SQLException ex) {

            Logger lgr = Logger.getLogger(Show_image.class.getName());
            lgr.log(Level.SEVERE, ex.getMessage(), ex);
            
        }
       
    }
}