package image_jar;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Class demonstrate Inserting Image into MySQL Database using Java
 * @author Ramesh Fadatare
 *
 */
public class insert_image {

    public static void main(String[] args) {

        String cs = "jdbc:mysql://localhost:3306/jasper";
        String user = "root";
        String password = "root";

        String sql = "INSERT INTO image(Data) VALUES(?)";

        try (Connection con = DriverManager.getConnection(cs, user, password); 
        		PreparedStatement pst = con.prepareStatement(sql)) {

            File myFile = new File("/home/prakash/pk.png");
            try (FileInputStream fin = new FileInputStream(myFile)) {

                pst.setBinaryStream(1, fin, (int) myFile.length());
                pst.executeUpdate();

            } catch (IOException ex) {

                Logger lgr = Logger.getLogger(insert_image.class.getName());
                lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        } catch (SQLException ex) {

            Logger lgr = Logger.getLogger(insert_image.class.getName());
            lgr.log(Level.SEVERE, ex.getMessage(), ex);
        }
    }
}