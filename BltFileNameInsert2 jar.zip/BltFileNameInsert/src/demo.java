import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import 

public class demo {
	
	
	public static void insertFileName() {
		BltTrxBeen been=new BltTrxBeen();
		
	    File dir = new File("//home//prakash//BltTrx");
        ArrayList<String> savefiles = new ArrayList<String>();
        for(File file : dir.listFiles()){
            savefiles.add(file.getName());
        }
        
        for (int i = 0; i < savefiles.size(); i++){
            String s = savefiles.get(i);
            System.out.println(s);
        }
	}
	public static void main(String[] args) {
		
		insertFileName();
 }
}
