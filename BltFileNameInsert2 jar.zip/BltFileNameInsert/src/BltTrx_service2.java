
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.path.connection.DbConnection;
import com.path.dto.pathBeen;


public class BltTrx_service2 {
	
	public static void main(String[] args) throws SQLException   {
		boolean status =false;		Path File_Name = Paths.get("//home//prakash//BltTrx");
		pathBeen been=new pathBeen(File_Name);
		ArrayList<pathBeen> arr=new ArrayList<pathBeen>();
		
		
		String SQL="INSERT INTO BltTrx (File_Name) VALUES(?)";
		
		
		try(Stream<Path> list = Files.list(File_Name);
				
				Connection connection = DbConnection.getConnection();
				PreparedStatement ps = connection.prepareStatement(SQL)) {
			
			List<Path> pathList = list.collect(Collectors.toList());
			System.out.println("Following files are saved in database..");
			int count=0;
			for (Path path : pathList) {
				System.out.println(path.getFileName());
				File file = path.toFile();
				String fileName = file.getName();
				//ps.setString(1, fileName);
				ps.setString(1,  file.getName());
				
				int x=ps.executeUpdate();
				if(x!=0) {
					status =true;
				}
				ps.addBatch();
				count++;
			}
			int[] executeBatch = ps.executeBatch();
			for (int i : executeBatch) {
				System.out.println(i);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}