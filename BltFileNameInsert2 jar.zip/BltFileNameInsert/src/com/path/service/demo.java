package com.path.service;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.path.connection.DbConnection;
import com.path.dto.pathBeen;


public class demo {
	
	public static boolean main(pathBeen been) {
		Connection con=null;
		boolean status =false;
		String SQL="INSERT INTO BltTrx (File_Name) VALUES(?)";
		Path File_Name = Paths.get("//home//prakash//BltTrx");
		
		try(Stream<Path> list = Files.list( File_Name);
				
				Connection connection = DbConnection.getConnection();
				PreparedStatement ps = connection.prepareStatement(SQL)) {
			
			List<Path> pathList = list.collect(Collectors.toList());
			System.out.println("Following files are saved in database..");
			int count=0;
			for (Path path : pathList) {
				System.out.println(path.getFileName());
				File file = path.toFile();
				ps.setString(1, been.getFile_Name());
				int x=ps.executeUpdate();
				if(x!=0) {
					status=true;
				}
				//ps.addBatch();
				count++;
			}
			int[] executeBatch = ps.executeBatch();
			for (int i : executeBatch) {
				System.out.println(i);
			}
			
		
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		return false;

		

	}

}
