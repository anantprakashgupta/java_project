package com.path.service;
import java.sql.*;

import com.path.connection.DbConnection;
import com.path.dto.pathBeen;

public class Showdata {
public static pathBeen dataBean = new pathBeen();

public static void main(String args[]) {
    getData();
    }



public static void getData () {

    try {
    	String File_Name;
    	Connection connection = DbConnection.getConnection();
     //   Class.forName("com.mysql.jdbc.Driver");
     //   Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jasper", 
      // "root", "root");
    
Statement stmt = connection.createStatement();
        ResultSet rs = stmt.executeQuery("select File_Name from BltTrx ORDER BY id DESC LIMIT 1;");
        System.out.println("rs  " + rs);
        int count = 1;
        while (rs.next()) {
            File_Name = rs.getString("File_Name");
            System.out.println(count  +": " + File_Name);
            count++;

        }

        connection.close();
    } catch (Exception e) {
    

        System.out.println(e.getMessage());
    }
    
    
}

}