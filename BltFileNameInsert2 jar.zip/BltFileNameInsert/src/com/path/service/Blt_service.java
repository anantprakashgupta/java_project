package com.path.service;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.path.connection.DbConnection;


public class Blt_service {
	
	public static void main(String[] args) throws SQLException   {
		
		String SQL="INSERT INTO BltTrx (File_Name)VALUES(?)";
		Path dir = Paths.get("//home//prakash//BltTrx");
		try
		(Stream<Path> list = Files.list(dir);
				Connection connection = DbConnection.getConnection();
				PreparedStatement ps = connection.prepareStatement(SQL)) {
			    List<Path> pathList = list.collect(Collectors.toList());

			//System.out.println(list.getClass());
			for (Path path : pathList) {
				System.out.println(path.getFileName());
				File file = path.toFile();
				String fileName = file.getName();
				ps.setString(1, fileName);
				ps.addBatch();
			    
				
				 
			}
			
			int[] executeBatch = ps.executeBatch();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}