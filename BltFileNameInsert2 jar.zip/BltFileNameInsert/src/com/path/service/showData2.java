package com.path.service;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.path.connection.DbConnection;
import com.path.dto.pathBeen;

public class showData2 {
public static void main(String args[]) {
    getData();
    }

public static <BltTrx> void getData () {
	 ArrayList<pathBeen> been1 = new ArrayList<pathBeen>();
	    pathBeen been = null;
    try {
    	Connection con = DbConnection.getConnection();
        String sql = "select * from BltTrx";
        PreparedStatement ps=con.prepareStatement(sql);
        ResultSet rs=(ResultSet) ps.executeQuery();
    	while(rs.next()) {
    		// been.setId(rs.getInt("id"));
         //    been.setFile_Name(rs.getString("File_Name"));
             
             int id=rs.getInt(1);
 			 String File_Name=rs.getString(2);
             been1.add(been);
    		
    	}

        
        con.close();
        rs.close();
    } catch (Exception e) {
    

        System.out.println(e.getMessage());
    }
    
    
}

}