package com.path.dto;

import java.nio.file.Path;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collector;

public class pathBeen {
    private int id;
	private String File_Name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFile_Name() {
		return File_Name;
	}
	public void setFile_Name(String file_Name) {
		File_Name = file_Name;
	}
	public pathBeen(int id, String file_Name) {
		super();
		this.id = id;
		File_Name = file_Name;
	}
	public pathBeen(Path file_Name) {
		super();
		// TODO Auto-generated constructor stub
	}
	public pathBeen() {
		// TODO Auto-generated constructor stub
	}

	
	

}
