package imageProcess;

import java.sql.*;
import java.io.*;

public class StoreImageIntoDB {
	
	public static void main(String args[])
	{
		String className = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost/jasper";
		String user = "root";
		String password = "root";
		Connection con = null;
		PreparedStatement ps = null;
		InputStream is = null;
		try
		{
			Class.forName(className);
			con = DriverManager.getConnection(url, user, password);
			//File image = new File("/home/prakash/Downloads/business_logo.png");
			InputStream image = new FileInputStream("/home/prakash/Downloads/business_logo.png");
			//is = new FileInputStream(image);
			ps = con.prepareStatement("insert into image(id,image)"
							+ "values(?,?)");
			ps.setInt(1, 1);
			ps.setBinaryStream(2, image);
			//ps.setBlob(1, ps.getimage);
			
						int i = ps.executeUpdate();
			if(i > 0)
			{
				System.out.println("Image Stored successfully");
			}
			ps.close();
			is.close();
		}
		catch(Exception e)
		{
			System.out.print(e);
		}
	}
}