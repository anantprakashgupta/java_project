//package DAO;
//
//import java.io.OutputStream;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.util.ArrayList;
//
//import com.mysql.jdbc.Blob;
//import com.mysql.jdbc.ResultSet;
//
//import DTO.imageDTO;
//import connection.dbConnection;
//
//
//public class imageDAO {
//	public static boolean registerStudent(imageDTO img) {
//		Connection con=null;
//		boolean status =false;
//		try {
//			con=dbConnection.getConnection();	
//			String sql="insert into student (name, address, password, roll)  value(?,?,?,?)COUNT(*)";
//			PreparedStatement ps=con.prepareStatement(sql);
//			ps.setString(1, img.getFirstname());
//			ps.setString(2, img.getImage());
//		
//			
//			int x=ps.executeUpdate();
//			if(x!=0) {
//				status =true;
//			}
//		
//		}catch(Exception e) {
//			e.printStackTrace();
//		}
//		
//		
//		return false;
//		
//		
//	}
////	public static  ArrayList<imageDTO> getimage() {
////		ArrayList<imageDTO> all=new ArrayList();
////		boolean status =false;
////		Connection con=null;
////		
////		try {
////			con=dbConnection.getConnection();	
////			String sql="select * from image2 where id=?";
////			PreparedStatement ps=con.prepareStatement(sql);
////			ps.setString(1, id);
////			ResultSet rs=(ResultSet) ps.executeQuery();
////			
////			if(rs.next()){
////		        Blob blob = rs.getBlob("image");
////		        String fisrtname=rs.getString("firstname");
////		        byte byteArray[] = blob.getBytes(1, (int)blob.length());
////		        response.setContentType("image/gif");
////		        OutputStream os = response.getOutputStream();
////		        os.write(byteArray);
////		        os.flush();
////		        os.close();
////			
////			
////			
////			
////			
////			String firstname=rs.getString(1);
////			String image=rs.getString(2);
////			imageDTO s=new imageDTO(id, firstname, image);
////			
////			all.add(s);
////			}
////			con.close();
////			
////		}catch(Exception e) {
////			e.printStackTrace();
////		}
////		return all;
////		
////		
////		
////		
////		
////	}
//
//}