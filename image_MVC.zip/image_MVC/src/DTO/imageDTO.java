package DTO;

public class imageDTO {
	private int id;
	private String firstname;
	private String image;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public imageDTO(int id, String firstname, String image) {
		super();
		this.id = id;
		this.firstname = firstname;
		this.image = image;
	}
	public imageDTO(String firstname, String image) {
		super();
		this.firstname = firstname;
		this.image = image;
	}
	public imageDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

}
